﻿using parcial1.EF;
using parcial1.Interfaces;

namespace parcial1.Repositories
{
    public class TramiteRepository(MiDBContext _context) : ITramiteRepository
    {
     
   
    }
}
