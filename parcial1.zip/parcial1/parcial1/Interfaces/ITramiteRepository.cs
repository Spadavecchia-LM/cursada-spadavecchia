﻿namespace parcial1.Interfaces
{
    public interface ITramiteRepository
    {
    }
}
