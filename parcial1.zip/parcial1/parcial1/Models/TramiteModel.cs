﻿namespace parcial1.Models
{
    public class TramiteModel
    {
    }
}
