﻿namespace parcial1.Models
{
    public class TitularModel
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Dni { get; set; }
    }
}
