﻿namespace parcial1.Models
{
    public class ProductoModel
    {
        
        public string Descripcion { get; set; }
        public int Precio { get; set; }
    }
}
